export const setUser = (username) => ({
  type: "SET_USER",
  payload: username,
});
